---
id: CP-02
titulo: Rechazo de archivo invalido
modulo: Carga
tipo_prueba: Sistema
requerimiento: REQ-01_Carga_Imagen
version_sistema: "1.0"
estado: Pendiente
entrada: Archivo PDF (formato no valido)
precondiciones: Sistema iniciado, pagina de carga visible
pasos:
  - 1. Hacer click en boton "Subir imagen"
  - 2. Seleccionar archivo PDF
  - 3. Confirmar seleccion
resultado_esperado: El sistema muestra un mensaje de error indicando formato invalido
resultado_actual: ""
paso_fallo: ""
severidad_defecto: ""
fecha_ejecucion: ""
responsable: ""
tags:
  - cp/pendiente
  - modulo/carga
  - req/funcional
---

# CP-02: Rechazo de archivo invalido

## 1. Informacion del Caso de Prueba

| Campo | Valor |
|-------|-------|
| **ID** | CP-02 |
| **Modulo** | Carga (Modulo-01) |
| **Tipo de Prueba** | Sistema |
| **Requerimiento** | [[REQ-01_Carga_Imagen]] |
| **Estado** | Pendiente |

## 2. Descripcion

Verificar que el sistema rechaza archivos con formatos no validos y muestra un mensaje apropiado.

## 3. Datos de Prueba

| Campo | Valor |
|-------|-------|
| Archivo de entrada | `documento.pdf` |
| Formato | PDF (no valido) |

## 4. Pasos de Ejecucion

1. Acceder a la pagina principal del sistema
2. Hacer click en el boton "Subir imagen"
3. Seleccionar un archivo PDF
4. Confirmar la seleccion

## 5. Resultado Esperado

- Se muestra mensaje de error: "Formato de archivo no valido. Solo se aceptan JPG, PNG, WebP"
- No se carga ningun archivo
- El sistema permanece en estado funcional

## 6. Criterios de Exito

- [ ] El sistema rechaza el archivo PDF
- [ ] Se muestra mensaje de error claro
- [ ] El sistema no se bloquea

## 7. Trazabilidad

- Requerimiento: [[REQ-01_Carga_Imagen]] - Regla de negocio RN-01-03
- Plan Maestro: [[00-Plan_Maestro_Pruebas]]

---

*Caso de prueba creado: 2026-03-23*