---
id: CP-09
titulo: Previsualizacion de marco doble
modulo: Previsualizacion
tipo_prueba: Sistema
requerimiento: REQ-07_Marcos_Dobles
version_sistema: "1.0"
estado: Pendiente
entrada: Dos fotos de cliente + seleccion de marco doble
precondiciones: Imagenes cargadas, marco doble seleccionado
pasos:
  - 1. Cargar primera foto del cliente
  - 2. Cargar segunda foto del cliente
  - 3. Seleccionar un marco doble
  - 4. Observar la previsualizacion
resultado_esperado: La previsualizacion muestra ambas fotos en el marco doble
resultado_actual: ""
paso_fallo: ""
severidad_defecto: ""
fecha_ejecucion: ""
responsable: ""
tags:
  - cp/pendiente
  - modulo/previsualizacion
  - req/pendiente
  - scope-creep
---

# CP-09: Previsualizacion de marco doble

## 1. Informacion del Caso de Prueba

| Campo | Valor |
|-------|-------|
| **ID** | CP-09 |
| **Modulo** | Previsualizacion (Modulo-03) |
| **Tipo de Prueba** | Sistema |
| **Requerimiento** | [[REQ-07_Marcos_Dobles]] |
| **Estado** | Pendiente (Scope Creep) |

## 2. Descripcion

Verificar que la previsualizacion muestra dos fotografias dentro de un marco doble.

## 3. Datos de Prueba

| Campo | Valor |
|-------|-------|
| Imagen 1 | foto_cliente_1.jpg |
| Imagen 2 | foto_cliente_2.jpg |
| Marco seleccionado | Marco doble |

## 4. Pasos de Ejecucion

1. Cargar primera foto
2. Cargar segunda foto
3. Seleccionar marco doble
4. Observar previsualizacion

## 5. Resultado Esperado

- Ambas fotos visibles en el marco
- Cada foto en su espacio designado
- Marco renderizado correctamente

## 6. Criterios de Exito

- [ ] Dos imagenes visibles
- [ ] Marco doble renderizado
- [ ] Sin errores de renderizado

## 7. Trazabilidad

- Requerimiento: [[REQ-07_Marcos_Dobles]]
- Change Request: [[CR-01_Marcos_Dobles]]
- Plan Maestro: [[00-Plan_Maestro_Pruebas]]

---

*Caso de prueba creado: 2026-03-23*