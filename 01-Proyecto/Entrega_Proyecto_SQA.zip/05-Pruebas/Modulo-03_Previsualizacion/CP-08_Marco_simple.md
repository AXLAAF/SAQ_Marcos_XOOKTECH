---
id: CP-08
titulo: Previsualizacion de marco simple
modulo: Previsualizacion
tipo_prueba: Sistema
requerimiento: REQ-02_Previsualizacion_Marco
version_sistema: "1.0"
estado: Pendiente
entrada: Foto de cliente cargada + seleccion de marco simple
precondiciones: Imagen del cliente cargada, catalogo cargado
pasos:
  - 1. Cargar foto del cliente
  - 2. Seleccionar un marco simple del catalogo
  - 3. Observar la previsualizacion
resultado_esperado: La previsualizacion muestra la foto del cliente con el marco seleccionado
resultado_actual: ""
paso_fallo: ""
severidad_defecto: ""
fecha_ejecucion: ""
responsable: ""
tags:
  - cp/pendiente
  - modulo/previsualizacion
  - req/funcional
---

# CP-08: Previsualizacion de marco simple

## 1. Informacion del Caso de Prueba

| Campo | Valor |
|-------|-------|
| **ID** | CP-08 |
| **Modulo** | Previsualizacion (Modulo-03) |
| **Tipo de Prueba** | Sistema |
| **Requerimiento** | [[REQ-02_Previsualizacion_Marco]], [[REQ-03_Generacion_Marcos_3D]] |
| **Estado** | Pendiente |

## 2. Descripcion

Verificar que la previsualizacion 3D renderiza correctamente un marco simple sobre la foto del cliente.

## 3. Datos de Prueba

| Campo | Valor |
|-------|-------|
| Imagen de entrada | foto_cliente.jpg |
| Marco seleccionado | Marco simple (no doble) |
| Renderizado esperado | Three.js/WebGL |

## 4. Pasos de Ejecucion

1. Cargar una foto de prueba en el sistema
2. Navegar al catalogo de marcos
3. Seleccionar un marco simple
4. Observar el renderizado de previsualizacion

## 5. Resultado Esperado

- El marco se rendered alrededor de la foto
- La perspectiva 3D es correcta
- La textura del marco se aplica adecuadamente
- El tiempo de renderizado es < 2 segundos

## 6. Criterios de Exito

- [ ] Marco visible en los 4 lados
- [ ] Textura aplicada correctamente
- [ ] Sin errores de WebGL
- [ ] Rendimiento aceptable

## 7. Trazabilidad

- Requerimientos: [[REQ-02_Previsualizacion_Marco]], [[REQ-03_Generacion_Marcos_3D]]
- Plan Maestro: [[00-Plan_Maestro_Pruebas]]

---

*Caso de prueba creado: 2026-03-23*