---
id: CP-13
titulo: Proyeccion en pantalla secundaria
modulo: Pantalla_Secundaria
tipo_prueba: Sistema
requerimiento: REQ-10_Pantalla_Secundaria
version_sistema: "1.0"
estado: Pendiente
entrada: Pantalla secundaria conectada
precondiciones: Sistema iniciado, TV/monitor secundario conectado
pasos:
  - 1. Conectar pantalla secundaria (TV via HDMI)
  - 2. Iniciar el sistema
  - 3. Seleccionar proyectar en pantalla secundaria
resultado_esperado: La previsualizacion aparece en la pantalla secundaria
resultado_actual: ""
paso_fallo: ""
severidad_defecto: ""
fecha_ejecucion: ""
responsable: ""
tags:
  - cp/pendiente
  - modulo/pantalla-secundaria
  - req/pendiente
  - scope-creep
---

# CP-13: Proyeccion en pantalla secundaria

## 1. Informacion del Caso de Prueba

| Campo | Valor |
|-------|-------|
| **ID** | CP-13 |
| **Modulo** | Pantalla Secundaria (Modulo-04) |
| **Tipo de Prueba** | Sistema |
| **Requerimiento** | [[REQ-10_Pantalla_Secundaria]] |
| **Estado** | Pendiente (Scope Creep) |

## 2. Descripcion

Verificar que el sistema puede proyectar la previsualizacion en una pantalla secundaria cuando esta conectada.

## 3. Datos de Prueba

| Campo | Valor |
|-------|-------|
| Pantalla secundaria | TV 32" via HDMI |
| Contenido esperado | Solo previsualizacion (sin UI) |

## 4. Pasos de Ejecucion

1. Conectar TV via HDMI
2. Abrir el sistema
3. Seleccionar "Proyectar en pantalla secundaria"
4. Observar la TV

## 5. Resultado Esperado

- El sistema detecta la pantalla secundaria
- Pregunta si desea proyectar
- La previsualizacion aparece en la TV
- La interfaz de control NO aparece en la TV

## 6. Criterios de Exito

- [ ] Pantalla detectada
- [ ] Proyeccion iniciada
- [ ] Solo previsualizacion visible

## 7. Trazabilidad

- Requerimiento: [[REQ-10_Pantalla_Secundaria]] - CA-01
- Change Request: [[CR-04_Pantalla_Secundaria]]
- Plan Maestro: [[00-Plan_Maestro_Pruebas]]

---

*Caso de prueba creado: 2026-03-23*