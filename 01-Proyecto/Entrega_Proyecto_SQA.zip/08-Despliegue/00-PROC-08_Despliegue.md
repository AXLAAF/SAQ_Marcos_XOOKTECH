# Proceso de Despliegue en Producción -- XookTech

**Área de proceso:** 08-Despliegue
**Nombre del proceso:** Transición a Entornos Productivos
**Responsable:** Líder de Desarrollo e Implementación
**Entradas:** Código en rama main y Plan de Pruebas Exitoso.
**Salidas:** Aplicación Flask operativa en VPS.

---

## Proceso

### 1. Preparación del Entorno
Verificar que el VPS tenga instaladas las dependencias de `requirements.txt` y que el servidor Nginx esté configurado para actuar como Proxy Inverso de Flask.

### 2. Despliegue del Código
1. Hacer pull de la rama `main` en el servidor.
2. Reiniciar el servicio de la aplicación (Gunicorn/Systemd).
3. Verificar la conectividad de la API en el puerto 5000.

### 3. Verificación Post-Despliegue
Ejecutar la [[08-Despliegue/Documentos_Apoyo/02-Formatos/CL-08-01_Verificacion_Despliegue|CL-08-01]] para asegurar que todos los módulos (Carga, 3D, Catálogo) funcionan en producción.

---

## Referencias
- **IEEE 12207**: Operation and Maintenance Processes.
