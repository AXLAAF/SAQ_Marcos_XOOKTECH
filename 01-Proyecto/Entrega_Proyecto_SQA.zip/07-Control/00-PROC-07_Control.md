# Gestión de Control de Calidad y Cambios -- XookTech

**Área de proceso:** 07-Control
**Nombre del proceso:** Aseguramiento y Control de Configuración
**Responsable:** Analista de Control y Cambios
**Entradas:** Artefactos Verificados y Solicitudes de Cambio (CR).
**Salidas:** Línea Base Controlada y Registro de Defectos.

---

## Proceso

### 1. Control de Configuración (Línea Base)
Todo documento que alcanza el estado de verificado se congela. Cualquier cambio posterior debe tramitarse mediante un **CR** siguiendo el [[07-Control/03-PROC-08_Control_Cambios|PROC-08 de Control de Cambios]].

### 2. Auditorías de Calidad
El **Analista de Control y Cambios** realiza inspecciones aleatorias sobre los procesos para asegurar que se cumple con el rigor bibliográfico (Galin/SWEBOK).

### 3. Gestión de Defectos
Los fallos detectados en las pruebas (05) se registran en el [[07-Control/02-REG-03_Registro_Defectos|REG-03]] para asegurar su cierre técnico antes del despliegue (08).
